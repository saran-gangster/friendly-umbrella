Install requirements

# pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib

Authorize the app and create the sheet



# python create_sheet.py
The first time you run this a browser will open and you have to login.
It creates and prints the sheetId.
Note: if this process doesn't work for you send me which email id you used to authenticate.

Update the sheets file

# python update_sheets.py