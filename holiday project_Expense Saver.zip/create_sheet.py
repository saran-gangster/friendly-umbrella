import sheets_utility as su


if __name__ == "__main__":
    service = su.create_authorized_service()
    su.create_sheet(service)
